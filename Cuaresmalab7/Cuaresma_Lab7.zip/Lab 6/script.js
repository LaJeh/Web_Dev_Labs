const inventory = [
  { id: 1, name: "produkto 1", price: 9.99, stock: 100 },
  { id: 2, name: "produkto 2", price: 19.5, stock: 50 },
  { id: 3, name: "produkto 3", price: 4.75, stock: 200 },
  { id: 4, name: "produkto 4", price: 14.0, stock: 25 },
  { id: 5, name: "produkto 5", price: 68766767676.99, stock: 10 }
];

function renderTable() {
  const tbody = document.getElementById('tableBody');
  tbody.innerHTML = '';

  inventory.forEach(item => {
    const row = `
      <tr>
        <td>${item.id}</td>
        <td>${item.name}</td>
        <td>${item.price.toFixed(2)}</td>
        <td>${item.stock}</td>
      </tr>
    `;
    tbody.innerHTML += row;
  });
}

// Konak no karaman lab 6 etoyen sir hehe
function submitForm(event) {
  event.preventDefault();

  const nameInput = document.getElementById('productName');
  const priceInput = document.getElementById('price');
  const stockInput = document.getElementById('stock');

  const name = nameInput.value.trim();
  const price = parseFloat(priceInput.value);
  const stock = parseInt(stockInput.value, 10);

  if (!name || isNaN(price) || isNaN(stock)) return;

  
  const newProduct = {
    id: inventory.length ? Math.max(...inventory.map(i => i.id)) + 1 : 1, 
    name: name, 
    price: price,
    stock: stock
  };

  inventory.push(newProduct);
  renderTable();

  nameInput.value = '';
  priceInput.value = '';
  stockInput.value = '';
}

document.addEventListener("DOMContentLoaded", () => {
  renderTable();
  document.getElementById('addForm').addEventListener('submit', submitForm);
});
