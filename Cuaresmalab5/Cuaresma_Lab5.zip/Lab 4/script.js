function append(el){
  var text = el.textContent;
  var textarea = document.getElementById('operate');
  textarea.value = textarea.value + text;
}

function showResult(){
    var textarea = document.getElementById('operate');
    textarea.value = eval(textarea.value);

    if (textarea.value % 100 != 0){
        let num = Math.floor(Math.random() * 30);
        let tempText = textarea.value + "+" + num;
        textarea.value = eval(tempText);
    }
}

function resetPage(){
    var textarea = document.getElementById('operate');
    textarea.value = '';
    alert("Clearing na po ang iyong website");
}